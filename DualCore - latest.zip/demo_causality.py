"""
Demonstration of Causal Imagination and Moral Logic in DualCore.

Shows how DualCore can simulate 'thinking through' events and actions,
fulfilling the Phase 2 'What-if' reasoning roadmap.
"""

from dualcore.core import DualCoreSystem
from dualcore.causality import CausalEngine, CounterfactualReasoning, MoralReasoningLayer

def main():
    print("=" * 75)
    print("DualCore: Causal Imagination & Strategic Thinking Demo")
    print("=" * 75)
    
    dc = DualCoreSystem()
    causal = CausalEngine(dc)
    imagination = CounterfactualReasoning(causal)
    moral = MoralReasoningLayer(causal)
    
    # ===========================================
    # 1. CAUSAL PREDICTION: "What if..."
    # ===========================================
    print("\n" + "-" * 50)
    print("1. CAUSAL PREDICTION: Simulating the effect of actions")
    print("-" * 50)
    
    scenarios = [
        ("raw data", "analyze"),
        ("scientific theory", "randomize"),
        ("neighborhood", "beautify"),
        ("truth", "corrupt")
    ]
    
    for concept, action in scenarios:
        res = causal.predict_effect(concept, action)
        print(f"\n  If we '{action}' -> '{concept}':")
        print(f"    Impact: {res['interpretation']}")
        print(f"    Key Shifts: {', '.join(res['impact_summary'])}")
    
    # ===========================================
    # 2. MORAL LOGIC: Ethics through Causal Impact
    # ===========================================
    print("\n" + "-" * 50)
    print("2. MORAL LOGIC: Evaluating intent and impact")
    print("-" * 50)
    
    acts = [
        ("The thief", "corrupt", "the child"),
        ("The teacher", "analyze", "the problem"),
        ("The artist", "beautify", "the ruins"),
        ("The AI", "randomize", "the database")
    ]
    
    for actor, action, target in acts:
        eval = moral.evaluate_intent(actor, action, target)
        status = f"[{eval['moral_valence']}]"
        print(f"\n  {actor} wants to {action} {target}:")
        print(f"    Verdict: {status}")
        print(f"    Impact on Target: {eval['impact_on_target']}")
        print(f"    Reasoning: {eval['reasoning']}")

    # ===========================================
    # 3. COUNTERFACTUAL IMAGINATION: The 'What-if' Abyss
    # ===========================================
    print("\n" + "-" * 50)
    print("3. COUNTERFACTUALS: High-level mental simulation")
    print("-" * 50)
    
    concepts = ["mathematics", "chaos", "dictatorship"]
    
    for concept in concepts:
        fact = imagination.imagine_opposite_fate(concept)
        print(f"\n  Imagine if '{concept}' lost its core nature:")
        print(f"    {fact['counterfactual_insight']}")
        
    print("\n" + "=" * 75)
    print("CONCLUSION: DualCore now has an 'Imagination' layer.")
    print("It doesn't just see the signal; it models the transformation.")
    print("=" * 75)

if __name__ == "__main__":
    main()
