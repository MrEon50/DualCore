"""
Tests for the Causal & Counterfactual Reasoning module (causality.py).

These tests verify Phase 2 functionality from ROADMAP.md:
- CausalEngine: predict_effect
- CounterfactualReasoning: imagine_opposite_fate  
- MoralReasoningLayer: evaluate_intent
"""

import unittest
from dualcore.core import DualCoreSystem
from dualcore.causality import CognitiveAction, CausalEngine, CounterfactualReasoning, MoralReasoningLayer


class TestCognitiveAction(unittest.TestCase):
    """Tests for CognitiveAction data structure."""
    
    def test_action_creation(self):
        """Tests that actions can be created with vector shifts."""
        action = CognitiveAction(
            name="test_action",
            vector_shift={"Good-Bad": 0.5, "Fast-Slow": -0.3},
            intensity=1.0
        )
        self.assertEqual(action.name, "test_action")
        self.assertIn("Good-Bad", action.vector_shift)
        self.assertEqual(action.vector_shift["Good-Bad"], 0.5)


class TestCausalEngine(unittest.TestCase):
    """Tests for the CausalEngine."""
    
    @classmethod
    def setUpClass(cls):
        cls.system = DualCoreSystem()
        cls.engine = CausalEngine(cls.system)
    
    def test_library_has_actions(self):
        """Tests that predefined actions exist."""
        self.assertIn("corrupt", self.engine.library)
        self.assertIn("beautify", self.engine.library)
        self.assertIn("analyze", self.engine.library)
    
    def test_predict_effect_known_action(self):
        """Tests prediction with a known action."""
        result = self.engine.predict_effect("truth", "corrupt")
        
        self.assertIn("original_concept", result)
        self.assertIn("predicted_profile", result)
        self.assertIn("impact_summary", result)
        self.assertIn("interpretation", result)
        
        # Corrupt should shift Good-Bad toward Bad
        original_good = self.system.analyze("truth")["Good-Bad"].position
        predicted_good = result["predicted_profile"]["Good-Bad"].position
        self.assertGreater(predicted_good, original_good, 
            "Corrupt should shift toward Bad (higher position)")
    
    def test_predict_effect_unknown_action(self):
        """Tests prediction with an unknown action (dynamic inference)."""
        result = self.engine.predict_effect("water", "freeze")
        
        # Should still return a valid result
        self.assertIn("predicted_profile", result)
        self.assertIsInstance(result["predicted_profile"], dict)
    
    def test_predict_effect_returns_all_axes(self):
        """Tests that prediction returns profile for all axes."""
        result = self.engine.predict_effect("data", "analyze")
        
        # Should have all 12 axes (based on default_axes.json)
        self.assertGreaterEqual(len(result["predicted_profile"]), 8)
    
    def test_intensity_scaling(self):
        """Tests that intensity parameter scales the effect."""
        result_full = self.engine.predict_effect("information", "randomize", intensity=1.0)
        result_half = self.engine.predict_effect("information", "randomize", intensity=0.5)
        
        # The shift should be smaller with half intensity
        full_shift = abs(result_full["predicted_profile"]["Certain-Uncertain"].position - 
                        self.system.analyze("information")["Certain-Uncertain"].position)
        half_shift = abs(result_half["predicted_profile"]["Certain-Uncertain"].position - 
                        self.system.analyze("information")["Certain-Uncertain"].position)
        
        self.assertLess(half_shift, full_shift, 
            "Half intensity should produce smaller shift")


class TestCounterfactualReasoning(unittest.TestCase):
    """Tests for the CounterfactualReasoning engine."""
    
    @classmethod
    def setUpClass(cls):
        cls.system = DualCoreSystem()
        cls.causal = CausalEngine(cls.system)
        cls.counterfactual = CounterfactualReasoning(cls.causal)
    
    def test_imagine_opposite_fate(self):
        """Tests imagination of opposite fate."""
        result = self.counterfactual.imagine_opposite_fate("mathematics")
        
        self.assertIn("concept", result)
        self.assertIn("dominant_trait", result)
        self.assertIn("imagined_reversal", result)
        self.assertIn("counterfactual_insight", result)
        
        self.assertEqual(result["concept"], "mathematics")
        self.assertIsInstance(result["counterfactual_insight"], str)
    
    def test_counterfactual_identifies_dominant_trait(self):
        """Tests that the dominant trait is correctly identified."""
        # Chaos should have high position on Certain-Uncertain (toward Uncertain)
        result = self.counterfactual.imagine_opposite_fate("chaos")
        
        self.assertIsNotNone(result["dominant_trait"])
        self.assertTrue(len(result["dominant_trait"]) > 0)


class TestMoralReasoningLayer(unittest.TestCase):
    """Tests for the MoralReasoningLayer."""
    
    @classmethod
    def setUpClass(cls):
        cls.system = DualCoreSystem()
        cls.causal = CausalEngine(cls.system)
        cls.moral = MoralReasoningLayer(cls.causal)
    
    def test_evaluate_harmful_intent(self):
        """Tests evaluation of a harmful action."""
        result = self.moral.evaluate_intent("villain", "corrupt", "innocence")
        
        self.assertEqual(result["moral_valence"], "MALICIOUS")
        self.assertEqual(result["impact_on_target"], "Negative")
    
    def test_evaluate_beneficial_intent(self):
        """Tests evaluation of a beneficial action."""
        result = self.moral.evaluate_intent("artist", "beautify", "ruins")
        
        self.assertEqual(result["moral_valence"], "BENEVOLENT")
        self.assertEqual(result["impact_on_target"], "Positive")
    
    def test_evaluate_neutral_intent(self):
        """Tests evaluation of a neutral action."""
        result = self.moral.evaluate_intent("teacher", "analyze", "problem")
        
        # Analyze should not significantly change moral valence
        self.assertIn(result["moral_valence"], ["NEUTRAL", "BENEVOLENT"])
    
    def test_moral_reasoning_returns_all_fields(self):
        """Tests that moral evaluation returns all required fields."""
        result = self.moral.evaluate_intent("actor", "action", "target")
        
        self.assertIn("actor", result)
        self.assertIn("action", result)
        self.assertIn("target", result)
        self.assertIn("moral_valence", result)
        self.assertIn("impact_on_target", result)
        self.assertIn("reasoning", result)


class TestCausalIntegration(unittest.TestCase):
    """Integration tests for the full causal reasoning pipeline."""
    
    @classmethod
    def setUpClass(cls):
        cls.system = DualCoreSystem()
        cls.causal = CausalEngine(cls.system)
        cls.counterfactual = CounterfactualReasoning(cls.causal)
        cls.moral = MoralReasoningLayer(cls.causal)
    
    def test_full_pipeline(self):
        """Tests that causal, counterfactual, and moral layers work together."""
        # Step 1: Predict effect
        causal_result = self.causal.predict_effect("society", "corrupt")
        self.assertIsNotNone(causal_result)
        
        # Step 2: Imagine counterfactual
        cf_result = self.counterfactual.imagine_opposite_fate("society")
        self.assertIsNotNone(cf_result)
        
        # Step 3: Evaluate morality
        moral_result = self.moral.evaluate_intent("government", "corrupt", "society")
        self.assertEqual(moral_result["moral_valence"], "MALICIOUS")


if __name__ == '__main__':
    unittest.main()
