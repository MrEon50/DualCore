"""
Tests for the Temporal Reasoning module (temporal.py).

Verifies:
- TemporalContext: Era detection and profile adjustment
- ConceptEvolution: Trace evolution and era comparison
"""

import unittest
from dualcore.core import DualCoreSystem
from dualcore.temporal import TemporalContext, ConceptEvolution


class TestTemporalReasoning(unittest.TestCase):
    """Tests for Temporal Reasoning capabilities."""
    
    @classmethod
    def setUpClass(cls):
        cls.system = DualCoreSystem()
        cls.temporal = TemporalContext(cls.system)
        cls.evolution = ConceptEvolution(cls.temporal)
    
    def test_era_detection_by_name(self):
        """Tests that eras can be retrieved by their name."""
        era = self.temporal.get_era("ancient")
        self.assertIsNotNone(era)
        self.assertEqual(era.name, "Ancient")
    
    def test_era_detection_by_alias(self):
        """Tests that eras can be retrieved by year aliases."""
        era = self.temporal.get_era("1960s")
        self.assertIsNotNone(era)
        self.assertEqual(era.name, "Modern")
    
    def test_era_detection_by_year(self):
        """Tests that eras can be retrieved by an integer year."""
        era = self.temporal.get_era("1500")
        self.assertIsNotNone(era)
        self.assertEqual(era.name, "Medieval")
    
    def test_analyze_in_era(self):
        """Tests that analysis yields different results for different eras."""
        # Simple concepts like "tool"
        ancient = self.temporal.analyze_in_era("tool", "ancient")
        ai_era = self.temporal.analyze_in_era("tool", "ai_era")
        
        self.assertEqual(ancient["era"], "Ancient")
        self.assertEqual(ai_era["era"], "AI Era")
        
        # Check that positions are different due to era shifts
        # AI Era has a strong shift on Fast-Slow (-0.6)
        pos_ancient = ancient["adjusted_profile"]["Fast-Slow"].position
        pos_ai = ai_era["adjusted_profile"]["Fast-Slow"].position
        
        # AI era should be 'faster' (lower position on Fast-Slow axis)
        self.assertNotEqual(pos_ancient, pos_ai)
    
    def test_trace_evolution(self):
        """Tests tracing the evolution of a concept."""
        evo = self.evolution.trace_evolution("medicine")
        
        self.assertEqual(evo["concept"], "medicine")
        self.assertIn("timeline", evo)
        self.assertIn("average_drift", evo)
        self.assertGreater(len(evo["timeline"]), 0)
    
    def test_compare_eras(self):
        """Tests direct comparison between two eras."""
        comparison = self.evolution.compare_eras("transportation", "ancient", "digital")
        
        self.assertEqual(comparison["era_a"], "Ancient")
        self.assertEqual(comparison["era_b"], "Digital")
        self.assertIn("significant_differences", comparison)
        
        # Transportation should be significantly faster in Digital era
        self.assertIn("Fast-Slow", comparison["significant_differences"])
    
    def test_invalid_era_handling(self):
        """Tests that system handles unknown eras gracefully."""
        result = self.temporal.analyze_in_era("test", "non_existent_era")
        self.assertIn("error", result)
        self.assertEqual(result["concept"], "test")

if __name__ == '__main__':
    unittest.main()
