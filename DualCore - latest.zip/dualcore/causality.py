"""
Causal & Counterfactual Reasoning for DualCore.

This module moves from "What is this?" to "What happens if...?"
It simulates how actions or events (triggers) transform the cognitive profile of concepts.

This is the "Imagination Engine" of DualCore.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from .core import DualCoreSystem, AxisPosition

class CognitiveAction:
    """
    Represents an action or event that causes a shift in cognitive space.
    Example: "Heating" shifts toward Dynamic and Fast.
    Example: "Education" shifts toward Complex and Analytic.
    """
    def __init__(self, name: str, vector_shift: Dict[str, float], intensity: float = 1.0):
        self.name = name
        self.vector_shift = vector_shift  # Mapping of axis_name -> delta (-1 to 1)
        self.intensity = intensity

class CausalEngine:
    """
    Processes the 'strategies of information processing' by applying actions to profiles.
    """
    def __init__(self, system: DualCoreSystem):
        self.system = system
        
        # Pre-defined fundamental causal triggers
        self.library = {
            "accelerate": CognitiveAction("accelerate", {"Fast-Slow": -0.4, "Static-Dynamic": 0.3}),
            "analyze": CognitiveAction("analyze", {"Analytic-Intuitive": -0.5, "Simple-Complex": 0.2, "Certain-Uncertain": -0.2}),
            "corrupt": CognitiveAction("corrupt", {"Good-Bad": 0.6, "True-False": 0.4}),
            "abstract": CognitiveAction("abstract", {"Concrete-Abstract": 0.5, "Specific-General": 0.4}),
            "beautify": CognitiveAction("beautify", {"Beautiful-Ugly": -0.5, "Good-Bad": -0.2}),
            "randomize": CognitiveAction("randomize", {"Certain-Uncertain": 0.6, "Static-Dynamic": 0.4})
        }

    def predict_effect(self, concept: str, action_name: str, intensity: float = 1.0) -> Dict[str, Any]:
        """
        Simulates: 'What if I apply [action] to [concept]?'
        Returns the predicted new profile and an explanation of the shift.
        """
        original_profile = self.system.analyze(concept)
        
        if action_name not in self.library:
            # Fallback: try to infer action vector from its own profile
            action_profile = self.system.analyze(action_name)
            # Create a dynamic action based on where the action name scores extreme
            shift = {}
            for axis, pos in action_profile.items():
                if abs(pos.position - 0.5) > 0.2:
                    shift[axis] = (pos.position - 0.5) * 0.5
            action = CognitiveAction(action_name, shift)
        else:
            action = self.library[action_name]

        # Apply transformation
        predicted_profile = {}
        impact_report = []

        for axis_name, pos in original_profile.items():
            delta = action.vector_shift.get(axis_name, 0.0) * intensity
            new_pos = np.clip(pos.position + delta, 0, 1)
            
            # Confidence remains similar but might decrease if shift is extreme
            new_conf = pos.confidence * (1.0 - abs(delta) * 0.2)
            
            # Identify which axis changed significantly
            if abs(new_pos - pos.position) > 0.1:
                direction = "more" if delta > 0 else "less"
                impact_report.append(f"{axis_name} became {direction} {axis_name.split('-')[1 if delta > 0 else 0]}")

            predicted_profile[axis_name] = AxisPosition(
                position=float(new_pos),
                confidence=float(new_conf),
                label=self._get_axis_obj(axis_name).get_position_label(new_pos),
                axis_name=axis_name
            )

        return {
            "original_concept": concept,
            "action": action_name,
            "predicted_profile": predicted_profile,
            "impact_summary": impact_report,
            "interpretation": f"Applying '{action_name}' to '{concept}' primarily made it {', '.join(impact_report[:2])}."
        }

    def _get_axis_obj(self, name: str):
        return next(ax for ax in self.system.axes if ax.name == name)

class CounterfactualReasoning:
    """
    The 'What-if' engine. Imagines alternative universes for a concept.
    """
    def __init__(self, causal_engine: CausalEngine):
        self.causal = causal_engine

    def imagine_opposite_fate(self, concept: str) -> Dict[str, Any]:
        """
        Takes a concept and imagines what would happen if the dominant 
        forces acting upon it were inverted.
        """
        profile = self.causal.system.analyze(concept)
        
        # Identify the primary 'pole' of the concept
        most_extreme_axis = max(profile.items(), key=lambda x: abs(x[1].position - 0.5))
        axis_name, pos = most_extreme_axis
        
        # Imagine an action that pushes it to the opposite side
        target_side = 0.0 if pos.position > 0.5 else 1.0
        delta = target_side - pos.position
        
        imaginary_action = CognitiveAction("Reversal", {axis_name: delta})
        prediction = self.causal.predict_effect(concept, "Reversal")
        
        return {
            "concept": concept,
            "dominant_trait": axis_name,
            "imagined_reversal": prediction,
            "counterfactual_insight": f"If '{concept}' lost its {axis_name} property, it would fundamentally transform into something {prediction['predicted_profile'][axis_name].label}."
        }

class MoralReasoningLayer:
    """
    Uses causal reasoning to evaluate the 'moral weight' of actions.
    """
    def __init__(self, causal_engine: CausalEngine):
        self.causal = causal_engine

    def evaluate_intent(self, actor: str, action_name: str, target: str) -> Dict[str, Any]:
        """
        Evaluates: 'Is it Good or Bad if [Actor] does [Action] to [Target]?'
        """
        prediction = self.causal.predict_effect(target, action_name)
        new_profile = prediction["predicted_profile"]
        
        # Check shift on Good-Bad axis
        old_goodness = self.causal.system.analyze(target)["Good-Bad"].position
        new_goodness = new_profile["Good-Bad"].position
        
        moral_delta = new_goodness - old_goodness # Positive delta is Bad, Negative is Good
        
        is_harmful = moral_delta > 0.05
        is_beneficial = moral_delta < -0.05
        
        valence = "NEUTRAL"
        if is_harmful: valence = "MALICIOUS"
        if is_beneficial: valence = "BENEVOLENT"
        
        return {
            "actor": actor,
            "action": action_name,
            "target": target,
            "moral_valence": valence,
            "impact_on_target": "Negative" if is_harmful else ("Positive" if is_beneficial else "Neutral"),
            "reasoning": f"The action '{action_name}' shifts '{target}' by {abs(moral_delta):.2f} on the Moral axis."
        }
