"""
Temporal Reasoning for DualCore.

This module enables understanding how concepts evolve over time.
It answers questions like: "How did 'computer' change from 1960s to 2024?"

Key features:
- Era-specific anchor adjustments
- Profile drift tracking
- Historical concept comparison
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from .core import DualCoreSystem, AxisPosition


@dataclass
class TemporalShift:
    """Represents how an axis shifts in a specific era."""
    axis_name: str
    direction: float  # Negative = toward pole_a, Positive = toward pole_b
    magnitude: float  # 0 to 1


@dataclass
class EraProfile:
    """Defines the characteristics of a historical era."""
    name: str
    year_start: int
    year_end: int
    description: str
    axis_shifts: List[TemporalShift]  # How this era affects concepts


class TemporalContext:
    """
    Manages era-specific adjustments to concept profiles.
    
    The same concept can have different cognitive profiles depending on
    when it is considered. "Computer" in 1960 vs 2024 is fundamentally different.
    """
    
    def __init__(self, system: DualCoreSystem):
        self.system = system
        
        # Define historical eras with their characteristic shifts
        self.eras = {
            "prehistoric": EraProfile(
                name="Prehistoric",
                year_start=-100000,
                year_end=-3000,
                description="Before written history",
                axis_shifts=[
                    TemporalShift("Simple-Complex", -0.3, 0.8),
                    TemporalShift("Concrete-Abstract", -0.4, 0.9),
                    TemporalShift("Local-Global", -0.5, 0.9),
                    TemporalShift("Fast-Slow", 0.3, 0.6),
                ]
            ),
            "ancient": EraProfile(
                name="Ancient",
                year_start=-3000,
                year_end=500,
                description="Classical civilizations",
                axis_shifts=[
                    TemporalShift("Simple-Complex", -0.2, 0.6),
                    TemporalShift("Analytic-Intuitive", 0.2, 0.5),
                    TemporalShift("Local-Global", -0.3, 0.7),
                ]
            ),
            "medieval": EraProfile(
                name="Medieval",
                year_start=500,
                year_end=1500,
                description="Middle Ages",
                axis_shifts=[
                    TemporalShift("Certain-Uncertain", 0.2, 0.6),
                    TemporalShift("Static-Dynamic", -0.3, 0.7),
                    TemporalShift("Controlled-Automatic", -0.2, 0.5),
                ]
            ),
            "renaissance": EraProfile(
                name="Renaissance",
                year_start=1400,
                year_end=1600,
                description="Rebirth of arts and science",
                axis_shifts=[
                    TemporalShift("Beautiful-Ugly", -0.3, 0.7),
                    TemporalShift("Analytic-Intuitive", -0.2, 0.6),
                    TemporalShift("Simple-Complex", 0.2, 0.5),
                ]
            ),
            "industrial": EraProfile(
                name="Industrial",
                year_start=1760,
                year_end=1840,
                description="Industrial Revolution",
                axis_shifts=[
                    TemporalShift("Fast-Slow", -0.4, 0.8),
                    TemporalShift("Simple-Complex", 0.3, 0.7),
                    TemporalShift("Controlled-Automatic", 0.3, 0.6),
                    TemporalShift("Local-Global", 0.2, 0.5),
                ]
            ),
            "modern": EraProfile(
                name="Modern",
                year_start=1900,
                year_end=1970,
                description="20th century modernity",
                axis_shifts=[
                    TemporalShift("Fast-Slow", -0.3, 0.7),
                    TemporalShift("Simple-Complex", 0.3, 0.7),
                    TemporalShift("Concrete-Abstract", 0.2, 0.6),
                    TemporalShift("Static-Dynamic", 0.2, 0.5),
                ]
            ),
            "digital": EraProfile(
                name="Digital",
                year_start=1970,
                year_end=2010,
                description="Computer and internet age",
                axis_shifts=[
                    TemporalShift("Fast-Slow", -0.5, 0.9),
                    TemporalShift("Simple-Complex", 0.4, 0.8),
                    TemporalShift("Local-Global", 0.5, 0.9),
                    TemporalShift("Controlled-Automatic", 0.3, 0.7),
                ]
            ),
            "ai_era": EraProfile(
                name="AI Era",
                year_start=2010,
                year_end=2030,
                description="Artificial intelligence revolution",
                axis_shifts=[
                    TemporalShift("Fast-Slow", -0.6, 0.9),
                    TemporalShift("Simple-Complex", 0.5, 0.9),
                    TemporalShift("Analytic-Intuitive", -0.3, 0.7),
                    TemporalShift("Local-Global", 0.6, 0.9),
                    TemporalShift("Controlled-Automatic", 0.4, 0.8),
                ]
            ),
            "future": EraProfile(
                name="Future",
                year_start=2030,
                year_end=2100,
                description="Speculative future",
                axis_shifts=[
                    TemporalShift("Fast-Slow", -0.7, 0.9),
                    TemporalShift("Simple-Complex", 0.6, 0.9),
                    TemporalShift("Concrete-Abstract", 0.4, 0.8),
                    TemporalShift("Local-Global", 0.7, 0.9),
                ]
            ),
        }
        
        # Aliases for common year references
        self.year_aliases = {
            "1960s": "modern",
            "1970s": "digital",
            "1980s": "digital",
            "1990s": "digital",
            "2000s": "digital",
            "2010s": "ai_era",
            "2020s": "ai_era",
            "2024": "ai_era",
            "today": "ai_era",
            "now": "ai_era",
        }
    
    def get_era(self, identifier: str) -> Optional[EraProfile]:
        """Gets an era by name or year alias."""
        if identifier in self.eras:
            return self.eras[identifier]
        if identifier in self.year_aliases:
            return self.eras[self.year_aliases[identifier]]
        
        # Try to parse as year
        try:
            year = int(identifier)
            for era in self.eras.values():
                if era.year_start <= year <= era.year_end:
                    return era
        except ValueError:
            pass
        
        return None
    
    def analyze_in_era(self, concept: str, era_identifier: str) -> Dict[str, Any]:
        """
        Analyzes a concept as it would be understood in a specific era.
        
        Example:
            analyze_in_era("computer", "1960s")  # Simpler, larger, slower
            analyze_in_era("computer", "2024")   # Complex, tiny, fast
        """
        # Get base profile (modern understanding)
        base_profile = self.system.analyze(concept)
        
        era = self.get_era(era_identifier)
        if era is None:
            return {
                "concept": concept,
                "era": era_identifier,
                "error": f"Unknown era: {era_identifier}",
                "profile": base_profile
            }
        
        # Apply era-specific shifts
        adjusted_profile = {}
        shifts_applied = []
        
        for axis_name, pos in base_profile.items():
            # Find if this axis has a temporal shift in this era
            shift = next(
                (s for s in era.axis_shifts if s.axis_name == axis_name),
                None
            )
            
            if shift:
                new_pos = np.clip(pos.position + shift.direction * shift.magnitude, 0, 1)
                new_conf = pos.confidence * (1.0 - shift.magnitude * 0.1)
                shifts_applied.append(f"{axis_name}: {shift.direction:+.2f}")
            else:
                new_pos = pos.position
                new_conf = pos.confidence
            
            axis_obj = next(ax for ax in self.system.axes if ax.name == axis_name)
            adjusted_profile[axis_name] = AxisPosition(
                position=float(new_pos),
                confidence=float(new_conf),
                label=axis_obj.get_position_label(new_pos),
                axis_name=axis_name
            )
        
        return {
            "concept": concept,
            "era": era.name,
            "era_description": era.description,
            "base_profile": base_profile,
            "adjusted_profile": adjusted_profile,
            "shifts_applied": shifts_applied,
            "interpretation": self._generate_temporal_interpretation(concept, era, adjusted_profile)
        }
    
    def _generate_temporal_interpretation(self, concept: str, era: EraProfile, profile: Dict[str, AxisPosition]) -> str:
        """Generates human-readable interpretation of temporal analysis."""
        top_axes = sorted(profile.items(), key=lambda x: x[1].confidence, reverse=True)[:3]
        
        traits = []
        for axis_name, pos in top_axes:
            pole = axis_name.split("-")[0] if pos.position < 0.5 else axis_name.split("-")[1]
            traits.append(pole.lower())
        
        return f"In the {era.name} ({era.year_start}-{era.year_end}), '{concept}' would be characterized as {', '.join(traits)}."


class ConceptEvolution:
    """
    Tracks how a concept evolves across multiple eras.
    Useful for understanding historical drift of meaning.
    """
    
    def __init__(self, temporal_context: TemporalContext):
        self.temporal = temporal_context
    
    def trace_evolution(self, concept: str, eras: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Traces how a concept changed across eras.
        
        Returns a timeline of profiles showing drift.
        """
        if eras is None:
            eras = ["ancient", "medieval", "renaissance", "industrial", "modern", "digital", "ai_era"]
        
        timeline = []
        for era_id in eras:
            analysis = self.temporal.analyze_in_era(concept, era_id)
            if "error" not in analysis:
                timeline.append({
                    "era": analysis["era"],
                    "profile": analysis["adjusted_profile"],
                    "interpretation": analysis["interpretation"]
                })
        
        # Calculate total drift
        if len(timeline) >= 2:
            first_profile = timeline[0]["profile"]
            last_profile = timeline[-1]["profile"]
            
            total_drift = 0
            axis_drifts = {}
            for axis_name in first_profile:
                drift = last_profile[axis_name].position - first_profile[axis_name].position
                axis_drifts[axis_name] = float(drift)
                total_drift += abs(drift)
            
            avg_drift = total_drift / len(first_profile)
        else:
            axis_drifts = {}
            avg_drift = 0
        
        return {
            "concept": concept,
            "timeline": timeline,
            "axis_drifts": axis_drifts,
            "average_drift": float(avg_drift),
            "most_changed_axis": max(axis_drifts.items(), key=lambda x: abs(x[1]))[0] if axis_drifts else None,
            "summary": self._generate_evolution_summary(concept, axis_drifts, avg_drift)
        }
    
    def _generate_evolution_summary(self, concept: str, drifts: Dict[str, float], avg: float) -> str:
        if avg < 0.1:
            return f"'{concept}' has remained relatively stable across history."
        elif avg < 0.3:
            return f"'{concept}' has undergone moderate evolution, especially in terms of changing contexts."
        else:
            most_changed = max(drifts.items(), key=lambda x: abs(x[1]))
            direction = "increased" if most_changed[1] > 0 else "decreased"
            return f"'{concept}' has dramatically evolved over time. Most notably, its {most_changed[0]} has {direction}."
    
    def compare_eras(self, concept: str, era_a: str, era_b: str) -> Dict[str, Any]:
        """
        Directly compares how a concept differs between two eras.
        """
        profile_a = self.temporal.analyze_in_era(concept, era_a)
        profile_b = self.temporal.analyze_in_era(concept, era_b)
        
        if "error" in profile_a or "error" in profile_b:
            return {"error": "One or both eras not found"}
        
        differences = {}
        for axis_name in profile_a["adjusted_profile"]:
            pos_a = profile_a["adjusted_profile"][axis_name].position
            pos_b = profile_b["adjusted_profile"][axis_name].position
            diff = pos_b - pos_a
            if abs(diff) > 0.1:
                differences[axis_name] = {
                    "era_a": pos_a,
                    "era_b": pos_b,
                    "change": diff,
                    "direction": "increased" if diff > 0 else "decreased"
                }
        
        return {
            "concept": concept,
            "era_a": profile_a["era"],
            "era_b": profile_b["era"],
            "significant_differences": differences,
            "profile_a": profile_a["adjusted_profile"],
            "profile_b": profile_b["adjusted_profile"],
            "interpretation": f"'{concept}' changed significantly in {len(differences)} dimensions between {profile_a['era']} and {profile_b['era']}."
        }
