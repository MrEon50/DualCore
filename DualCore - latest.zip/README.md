# DualCore 🧠 — Cognitive Architecture for AI Reasoning

**DualCore** is a revolutionary cognitive architecture that provides AI with a human-like coordinate system for understanding, reasoning, and evaluating concepts. Instead of operating in undefined high-dimensional embedding spaces, DualCore maps everything onto **12 fundamental Dual Axes** — giving AI a "north star" for thought.

> **"If you see WHITE, you should KNOW that BLACK exists — even without seeing it."**
> — This is the essence of understanding duality, and now AI can do it too.

---

## 🚀 Key Features

### ⚓ Anchor Sets — The "White vs Black" Detection
Each pole (e.g., *Good* or *Evil*) is anchored by a cluster of semantically rich concepts. This ensures the system always has fixed reference points for extremes, enabling precise detection of opposites.

### 🧠 Pole Inference — True Understanding
DualCore doesn't just classify — it **infers**. If it sees "love", it knows "hate" must exist. This is the bridge between pattern matching and genuine understanding.

### 🔄 Causal Imagination — "What if...?" Thinking
The `CausalEngine` allows the system to simulate how actions transform concepts. It can predict the effect of "heating" on "ice" or "education" on "mind" in cognitive space.

### 🕰️ Temporal Reasoning — Meaning through Eras
Concepts aren't static. DualCore understands how "medicine" evolved from the Medieval era to the AI Era, tracking drift across historical contexts.

### 🔍 Paradox Detection — Logical Impossibility Filter
The system detects logical contradictions like "hot ice" or "true lie" and flags them as paradoxes. This enables AI safety checks and prevents generation of impossible statements.

### 🧬 Adaptive Axis Discovery — Self-Evolution
When encountering concepts that don't fit existing axes, DualCore can discover new dimensions automatically. The system evolves with your data.

### 🔗 Neural Network Integration — Co-Evolution
DualCore provides a cognitive layer for neural networks, enabling them to learn structured reasoning. The `NeuralDualCoreInterface` allows bidirectional communication.

### 📊 Confidence Scores — Know What You Don't Know
Every projection includes a confidence score indicating how relevant an axis is to the concept. Orthogonal concepts get low confidence, aligned concepts get high.

---

## 🛠 Installation

```bash
pip install -r requirements.txt
pip install -e .
```

---

## 📖 Quick Start

### Basic Analysis
```python
from dualcore.core import DualCoreSystem

dc = DualCoreSystem()

# Analyze a concept
profile = dc.analyze("artificial intelligence", context="computer science")

# Access interpretable positions with confidence
for axis_name, pos in profile.items():
    print(f"{axis_name}: {pos.position:.2f} (conf: {pos.confidence:.2f}) — {pos.label}")
```

### Causal Reasoning (What-if?)
```python
from dualcore.causality import CausalEngine

causal = CausalEngine(dc)

# Predict effect of an action
result = causal.predict_effect("raw data", "analyze")
print(result["interpretation"]) 
# "Applying 'analyze' to 'raw data' primarily made it more Complex, less Intuitive."
```

### Temporal Evolution
```python
from dualcore.temporal import TemporalContext

temporal = TemporalContext(dc)

# See how a concept looked in the past
result = temporal.analyze_in_era("computer", "1960s")
print(result["interpretation"])
# "In the Modern (1900-1970), 'computer' would be characterized as abstract, controlled..."
```

### Paradox Detection
```python
from dualcore.reasoning import ParadoxDetector

detector = ParadoxDetector(dc)

# Check for logical impossibilities
report = detector.detect_paradox("the hot ice melted")
print(f"Is Paradox: {report.is_paradox}")  # True
```

### Pole Inference — Understanding Duality
```python
from dualcore.inference import PoleInferenceEngine

engine = PoleInferenceEngine(dc)

# Infer what the opposite would be
result = engine.infer_opposite("chaos")
print(f"Opposite of 'chaos': {result.inferred_opposite}")  # "order"
```

---

## ⚖️ The 12 Fundamental Axes

### 🏗️ Structure
| Axis | Description |
|------|-------------|
| **Simple ↔ Complex** | Structural and relational depth |
| **Concrete ↔ Abstract** | Physical tangibility vs. conceptual theory |
| **Local ↔ Global** | Scope of influence and relevance |
| **Specific ↔ General** | Precision vs. universal applicability |

### ⚙️ Process
| Axis | Description |
|------|-------------|
| **Fast ↔ Slow** | Temporal dynamics and speed |
| **Analytic ↔ Intuitive** | Systematic vs. instinctive reasoning |
| **Static ↔ Dynamic** | Stability vs. continuous evolution |
| **Controlled ↔ Automatic** | Deliberate vs. spontaneous reaction |

### 💎 Value (Axiology/Epistemology)
| Axis | Description |
|------|-------------|
| **Certain ↔ Uncertain** | Epistemic confidence and predictability |
| **True ↔ False** | Veracity and logical correctness |
| **Good ↔ Bad** | Moral valence and ethical value |
| **Beautiful ↔ Ugly** | Aesthetic harmony and quality |

---

## 🧪 Testing & Validation

DualCore includes a comprehensive test suite and benchmark:

```bash
# Run all 52 unit tests
python -m unittest discover -s tests

# Run accuracy benchmark
python benchmarks/run_benchmarks.py
```

### Current Benchmark Results (v0.4.0)
| Category | Accuracy |
|----------|----------|
| Semantic Ordering | 93.3% |
| Paradox Detection | 100.0% |
| Analogy Reasoning | 60.0% |
| Confidence Calibration | 80.0% |
| **Overall** | **90.0%** |

---

## 📁 Project Structure

```
DualCore/
├── dualcore/
│   ├── core.py           # Main system (12 axes, confidence)
│   ├── reasoning.py      # Paradox detection + Analogies
│   ├── inference.py      # Pole inference + Neural API
│   ├── causality.py      # Causal & Counterfactual reasoning
│   ├── temporal.py       # Temporal & Era-based analysis
│   ├── adaptive.py       # Self-evolving axes
│   ├── composites.py     # Second-order dimensions
│   └── integration/      # PyTorch integration
├── tests/                # 52 comprehensive tests
├── benchmarks/           # Accuracy measurement
└── demos/                # Usage examples
```

---

## 🔮 Philosophy

DualCore is built on a fundamental insight: **Human thought operates in dualities**. We understand "hot" because we know "cold" exists. We grasp "good" by its contrast with "evil". This architecture gives AI the same cognitive structure.

Unlike black-box embeddings, DualCore provides:
- **Interpretability**: Know *why* concepts are similar
- **Causality**: Predict how actions change the state of mind
- **Inference**: Deduce what must exist from what is observed
- **Constraints**: Prevent logically impossible outputs

---

## 📄 License

MIT License — Free for research and commercial use.

---

## 🤝 Contributing

Contributions welcome! See `ROADMAP.md` for planned features.

---

*DualCore: Teaching AI to think in opposites, so it can understand the whole.*
