"""
Demonstration of Temporal Reasoning in DualCore.

Shows how concepts evolve over time and how their cognitive profiles
change depending on the historical era.
"""

from dualcore.core import DualCoreSystem
from dualcore.temporal import TemporalContext, ConceptEvolution


def main():
    print("=" * 75)
    print("DualCore: Temporal Reasoning - How Concepts Evolve Over Time")
    print("=" * 75)
    
    dc = DualCoreSystem()
    temporal = TemporalContext(dc)
    evolution = ConceptEvolution(temporal)
    
    # ===========================================
    # 1. SINGLE CONCEPT IN DIFFERENT ERAS
    # ===========================================
    print("\n" + "-" * 50)
    print("1. 'COMPUTER' Across History")
    print("-" * 50)
    
    eras_to_test = ["1960s", "1990s", "2024"]
    
    for era in eras_to_test:
        result = temporal.analyze_in_era("computer", era)
        print(f"\n  Era: {result['era']}")
        print(f"  {result['interpretation']}")
        
        # Show key axis positions
        profile = result['adjusted_profile']
        print(f"    Simple-Complex: {profile['Simple-Complex'].position:.2f} ({profile['Simple-Complex'].label})")
        print(f"    Fast-Slow: {profile['Fast-Slow'].position:.2f} ({profile['Fast-Slow'].label})")
        print(f"    Local-Global: {profile['Local-Global'].position:.2f} ({profile['Local-Global'].label})")
    
    # ===========================================
    # 2. CONCEPT EVOLUTION TIMELINE
    # ===========================================
    print("\n" + "-" * 50)
    print("2. Evolution of 'COMMUNICATION'")
    print("-" * 50)
    
    evo = evolution.trace_evolution("communication")
    
    print(f"\n  Average Drift: {evo['average_drift']:.2f}")
    print(f"  Most Changed Axis: {evo['most_changed_axis']}")
    print(f"\n  Summary: {evo['summary']}")
    
    print("\n  Timeline:")
    for era_data in evo['timeline']:
        print(f"    - {era_data['era']}: {era_data['interpretation'][:60]}...")
    
    # ===========================================
    # 3. DIRECT ERA COMPARISON
    # ===========================================
    print("\n" + "-" * 50)
    print("3. Comparing 'MEDICINE' Between Eras")
    print("-" * 50)
    
    comparison = evolution.compare_eras("medicine", "medieval", "ai_era")
    
    print(f"\n  {comparison['interpretation']}")
    print("\n  Significant Changes:")
    for axis, data in comparison['significant_differences'].items():
        print(f"    - {axis}: {data['direction']} by {abs(data['change']):.2f}")
    
    # ===========================================
    # 4. ABSTRACT CONCEPTS THROUGH TIME
    # ===========================================
    print("\n" + "-" * 50)
    print("4. How Abstract Concepts Changed")
    print("-" * 50)
    
    abstract_concepts = ["truth", "justice", "beauty"]
    
    for concept in abstract_concepts:
        ancient = temporal.analyze_in_era(concept, "ancient")
        modern = temporal.analyze_in_era(concept, "ai_era")
        
        ancient_pos = ancient['adjusted_profile']['Concrete-Abstract'].position
        modern_pos = modern['adjusted_profile']['Concrete-Abstract'].position
        
        drift = modern_pos - ancient_pos
        direction = "more abstract" if drift > 0 else "more concrete"
        
        print(f"\n  '{concept}':")
        print(f"    Ancient: {ancient_pos:.2f} | AI Era: {modern_pos:.2f}")
        print(f"    Became {direction} over time (drift: {drift:+.2f})")
    
    print("\n" + "=" * 75)
    print("CONCLUSION: DualCore now understands temporal context.")
    print("The same word means different things in different eras.")
    print("=" * 75)


if __name__ == "__main__":
    main()
